<?php
$conexion = mysqli_connect("localhost", "root", "", "pañalera");

if (!$conexion) {
    die("Error en la conexión: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $empleado_cod = $_POST['empleado_cod'];

    $consulta = "SELECT * FROM nomina WHERE EMPLEADO_COD = $empleado_cod";
    $resultado = mysqli_query($conexion, $consulta);

    if ($resultado) {
        if (mysqli_num_rows($resultado) > 0) {
            // Mostrar los resultados
            echo "<h2>Resultados de la búsqueda:</h2>";
            echo "<table border='1'>
                    <tr>
                        <th>ID Nómina</th>
                        <th>Código Empleado</th>
                        <th>Salario</th>
                        <th>Días Trabajados</th>
                        <th>Salario Base</th>
                        <th>Horas Extras</th>
                        <th>Tipo Horas</th>
                        <th>Valor Horas</th>
                        <th>Auxilio de Transporte</th>
                        <th>Comisiones</th>
                        <th>Total Devengado</th>
                        <th>Pensión</th>
                        <th>Salud</th>
                        <th>Prestamos / Otros</th>
                        <th>Total Deducido</th>
                        <th>Neto Pagar</th>
                    </tr>";

            while ($fila = mysqli_fetch_assoc($resultado)) {
                echo "<tr>
                        <td>{$fila['ID_NOMINA']}</td>
                        <td>{$fila['EMPLEADO_COD']}</td>
                        <td>{$fila['SALARIO']}</td>
                        <td>{$fila['DIAS_TRABAJADOS']}</td>
                        <td>{$fila['SALARIO_BASE']}</td>
                        <td>{$fila['HORAS_EXTRAS']}</td>
                        <td>{$fila['TIPO_HORAS']}</td>
                        <td>{$fila['VALOR_HORAS']}</td>
                        <td>{$fila['AUXILIO_TRANSPORTE']}</td>
                        <td>{$fila['COMISIONES']}</td>
                        <td>{$fila['TOTAL_DEVENGADO']}</td>
                        <td>{$fila['PENSION']}</td>
                        <td>{$fila['SALUD']}</td>
                        <td>{$fila['PRESTAMOS_OTROS']}</td>
                        <td>{$fila['TOTAL_DEDUCIDO']}</td>
                        <td>{$fila['NETO_PAGAR']}</td>
                    </tr>";
            }

            echo "</table>";
        } else {
            echo "No se encontraron resultados para el código de empleado proporcionado.";
        }
    } else {
        echo "Error en la consulta: " . mysqli_error($conexion);
    }

    mysqli_free_result($resultado);
}

mysqli_close($conexion);
?>

