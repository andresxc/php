<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../CSS/productos.css">
        <title>Formulario de Productos</title>
    </head>

    <body>
        <h1>Formulario de Productos</h1>
        <form id="productos-form"  action="../INSERTAR/insertproducto.php" method="POST">
            <label for="categoria">Categoria:</label>
            <select id="categoria" name="categoria">
                <option value="aseo">Aseo</option>
                <option value="vestuario">Vestuario</option>
                <option value="alimentos">Alimentos</option>
                <option value="accesorios">Accesorios</option>
            </select>

            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required>

            <label for="cantidad">Cantidad:</label>
            <input type="number" step="0.01" id="cantidad" name="cantidad" required>

            <label for="lote">Lote:</label>
            <input type="number" step="0.01" id="lote" name="lote" required>

            <label for="fecha_fabricacion">Fecha de Fabricación:</label>
            <input type="date" id="fecha_fabricacion" name="fecha_fabricacion">

            <label for="fecha_venta">Fecha de Vencimiento:</label>
            <input type="date" id="fecha_venta" name="fecha_venta">

            <label for="precio_venta">Precio de Venta:</label>
            <input type="number" step="0.01" id="precio_venta" name="precio_venta" required>

            <label for="precio_compra">Precio de Compra:</label>
            <input type="number" step="0.01" id="precio_compra" name="precio_compra" required>
            
            <label for="id_proveedor">ID Proveedor:</label>
            <select id="id_proveedor" name="id_proveedor">
                <?php
                    $conn = mysqli_connect("localhost", "root", "", "pañalera");

                    // Consulta para obtener los cargos desde la base de datos
                    $result = mysqli_query($conn,"SELECT id_proveedores,razon_social  FROM proveedores") or die 
                    ("Problemas en el Select".mysqli_error($conn));

                    // Generar las opciones del select
                    while ($row = mysqli_fetch_array($result)) {
                        echo "<option value='". $row["id_proveedores"]."'>".$row["razon_social"]."</option>";
                    }
                ?>
            </select>

            <button type="submit">Guardar</button>
            <button type="reset">Borrar Datos</button>
            <a class="boton-link" href="../index.html">Regresar</a>
        </form>
    </body>

</html>