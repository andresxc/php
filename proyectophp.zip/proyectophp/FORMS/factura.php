<!DOCTYPE html>
<html lang="es">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../CSS/factura.css">
        <title>Formulario de Factura</title>
    </head>

    <body>
        <h1>Formulario de Factura</h1>
        <form id="factura-form" action="../INSERTAR/insertfactura.php" method="POST">

            <label for="id_factura">ID Factura:</label>
            <input type="number" id="id_factura" name="id_factura" required>

            <label for="cliente_cod">Codigo Cliente:</label>
            <select type="number" id="cliente_cod" name="cliente_cod" required>

            <?php
                    $conn = mysqli_connect("localhost", "root", "", "pañalera");

                    // Consulta para obtener los cargos desde la base de datos
                    $result = mysqli_query($conn,"SELECT id_cliente,apellido,nombre  FROM clientes order by apellido asc") or die 
                    ("Problemas en el Select".mysqli_error($conn));

                    // Generar las opciones del select
                    while ($row = mysqli_fetch_array($result)) {
                        echo "<option value='". $row["id_cliente"]."'>".$row["apellido"]." ".$row["nombre"]."</option>";
                    }
                ?>
</select>
            <label for="empledado_cod">ID empledado_cod:</label>
            <select type="number" id="empledado_cod" name="empledado_cod" required>

            <?php
                    $conn = mysqli_connect("localhost", "root", "", "pañalera");

                    // Consulta para obtener los cargos desde la base de datos
                    $result = mysqli_query($conn,"SELECT id_empleado,apellido,nombre  FROM empleados order by apellido asc") or die 
                    ("Problemas en el Select".mysqli_error($conn));

                    // Generar las opciones del select
                    while ($row = mysqli_fetch_array($result)) {
                        echo "<option value='". $row["id_empleado"]."'>".$row["apellido"]." ".$row["nombre"]."</option>";
                    }
                ?>
</select>
            <label for="producto_cod">ID Producto:</label>
            <select type="number" id="producto_cod" name="producto_cod" required>

            <?php
                    $conn = mysqli_connect("localhost", "root", "", "pañalera");

                    // Consulta para obtener los cargos desde la base de datos
                    $result = mysqli_query($conn,"SELECT id_producto,categoria,nombre  FROM productos order by categoria asc") or die 
                    ("Problemas en el Select".mysqli_error($conn));

                    // Generar las opciones del select
                    while ($row = mysqli_fetch_array($result)) {
                        echo "<option value='". $row["id_producto"]."'>".$row["categoria"]." ".$row["nombre"]."</option>";
                    }
                ?>
                </select>

            <label for="forma_pago">Forma de Pago:</label>
            <select id="forma_pago" name="forma_pago">
                <option value="efectivo">Efectivo</option>
                <option value="datafono">Datafono</option>
                <option value="cheque">Cheque</option>
                <option value="transferencias">Transferencias</option>
            </select>

            <label for="fecha_emision">Fecha de Emisión:</label>
            <input type="date" id="fecha_emision" name="fecha_emision">

            <label for="cantidad">Cantidad:</label>
            <input type="number" step="0.01" id="cantidad" name="cantidad" required>

            <label for="precio_unitario">Precio Unitario:</label>
            <input type="number" step="0.01" id="precio_unitario" name="precio_unitario" required>

            <label for="subtotal">Subtotal:</label>
            <input type="number" step="0.01" id="subtotal" name="subtotal" required>

            <label for="iva">Iva:</label>
            <input type="number" step="0.01" id="iva" name="iva" required>

            <label for="descuento">Descuento:</label>
            <input type="number" step="0.01" id="descuento" name="descuento" required>


            <label for="neto_pagar">Neto Pagar:</label>
            <input type="number" step="0.01" id="neto_pagar" name="neto_pagar" required>

            <button type="submit">Guardar</button>
            <button type="reset">Borrar Datos</button>
            <a class="boton-link" href="../index.html">Regresar</a>
        </form>
    </body>

</html>