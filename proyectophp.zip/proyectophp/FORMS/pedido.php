<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/pedido.css">
    <title>Formulario de Pedido</title>
</head>

<body>
    <div class="container">
        <h1>Formulario de Pedido</h1>
        <form id="pedidos-form" action="../INSERTAR/insertarpedido.php" method="POST">

            <label for="id_pedido">ID Pedido:</label>
            <input type="number" id="id_pedido" name="id_pedido" required>

            <label for="proveedor_cod">ID Proveedor:</label>
            <select type="number" id="proveedor_cod" name="proveedor_cod" required>
                <?php
                $conn = mysqli_connect("localhost", "root", "", "pañalera");

                // Consulta para obtener los proveedores desde la base de datos
                $result = mysqli_query($conn, "SELECT id_proveedores, razon_social FROM proveedores ORDER BY razon_social ASC") or die("Problemas en el Select" . mysqli_error($conn));

                // Generar las opciones del select
                while ($row = mysqli_fetch_array($result)) {
                    echo "<option value='" . $row["id_proveedores"] . "'>" . $row["razon_social"] . "</option>";
                }
                ?>
            </select>

            <label for="empleado_cod">ID Empleado:</label>
            <select type="number" id="empleado_cod" name="empleado_cod" required>
                <?php
                // Consulta para obtener los empleados desde la base de datos
                $result = mysqli_query($conn, "SELECT id_empleado, apellido, nombre FROM empleados ORDER BY apellido ASC") or die("Problemas en el Select" . mysqli_error($conn));

                // Generar las opciones del select
                while ($row = mysqli_fetch_array($result)) {
                    echo "<option value='" . $row["id_empleado"] . "'>" . $row["apellido"] . " " . $row["nombre"] . "</option>";
                }
                ?>
            </select>

            <label for="fecha_expedicion">Fecha de Expedición:</label>
            <input type="date" id="fecha_expedicion" name="fecha_expedicion">

            <label for="fecha_entrega">Fecha de Entrega:</label>
            <input type="date" id="fecha_entrega" name="fecha_entrega">

            <label for="forma_pago">Forma de Pago:</label>
            <select id="forma_pago" name="forma_pago">
                <option value="efectivo">Efectivo</option>
                <option value="datafono">Datafono</option>
                <option value="cheque">Cheque</option>
                <option value="transferencias">Transferencias</option>
            </select>

            <label for="cantidad">Cantidad:</label>
            <input type="number" step="0.01" id="cantidad" name="cantidad" required>

            <label for="precio_unitario">Precio Unitario:</label>
            <input type="number" step="0.01" id="precio_unitario" name="precio_unitario" required>

            <label for="subtotal">Subtotal:</label>
            <input type="number" step="0.01" id="subtotal" name="subtotal" required>

            <button type="submit">Guardar</button>
            <button type="reset">Borrar Datos</button>
            <a class="boton-link" href="../index.html">Regresar</a>
        </form>
    </div>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $conexion = mysqli_connect("localhost", "root", "", "farmacia");
        if (!$conexion) {
            die("Error en la conexión: " . mysqli_connect_error());
        }

        $id_pedido = $_POST['id_pedido'];
        $proveedor_cod = $_POST['proveedor_cod'];
        $empleado_cod = $_POST['empleado_cod'];
        $fecha_expedicion = $_POST['fecha_expedicion'];
        $fecha_entrega = $_POST['fecha_entrega'];
        $forma_pago = $_POST['forma_pago'];
        $cantidad = $_POST['cantidad'];
        $precio_unitario = $_POST['precio_unitario'];
        $subtotal = $_POST['subtotal'];

        $sql_cabeza = "INSERT INTO pedido_cabeza (ID_PEDIDO, PROVEEDOR_COD, EMPLEADO_COD, FECHA_EXPEDICION, FECHA_ENTREGA, FORMA_PAGO, CANTIDAD, PRECIO_UNITARIO, SUBTOTAL) 
        VALUES ('$id_pedido', '$proveedor_cod', '$empleado_cod', '$fecha_expedicion', '$fecha_entrega', '$forma_pago', '$cantidad', '$precio_unitario', '$subtotal')";

        if (mysqli_query($conexion, $sql_cabeza)) {
            echo "Registro de Pedido Cabeza Ingresado Correctamente <br><br>";
        } else {
            echo "Error en el Insert de Pedido Cabeza: " . mysqli_error($conexion);
        }

        $sql_detalle = "INSERT INTO pedido_detalle (ID_PEDIDO, PROVEEDOR_COD, EMPLEADO_COD, FECHA_EXPEDICION, FECHA_ENTREGA, FORMA_PAGO, CANTIDAD, PRECIO_UNITARIO, SUBTOTAL) 
            VALUES ('$id_pedido', '$proveedor_cod', '$empleado_cod', '$fecha_expedicion', '$fecha_entrega', '$forma_pago', '$cantidad', '$precio_unitario', '$subtotal')";

        if (mysqli_query($conexion, $sql_detalle)) {
            echo "Registro de Detalle de Pedido Ingresado Correctamente <br><br>";
        } else {
            echo "Error en el Insert de Detalle de Pedido: " . mysqli_error($conexion);
        }

        mysqli_close($conexion);
    }
    ?>
</body>

</html>
