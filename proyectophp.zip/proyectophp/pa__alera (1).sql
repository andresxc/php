-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-10-2023 a las 23:54:43
-- Versión del servidor: 10.4.27-MariaDB
-- Versión de PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `pañalera`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cargos`
--

CREATE TABLE `cargos` (
  `ID_CARGO` int(11) NOT NULL,
  `DESCRIPCION` varchar(80) DEFAULT NULL,
  `UBICACION` varchar(100) DEFAULT NULL,
  `SALARIO` double DEFAULT NULL,
  `COMISION` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cargos`
--

INSERT INTO `cargos` (`ID_CARGO`, `DESCRIPCION`, `UBICACION`, `SALARIO`, `COMISION`) VALUES
(5, 'operador', 'planta', 100000000, 10),
(6, 'operador', 'planta', 1000000, 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `ID_CLIENTE` int(11) NOT NULL,
  `NOMBRE` varchar(50) NOT NULL,
  `APELLIDO` varchar(50) NOT NULL,
  `TIPO_DOCUMENTO` enum('C.C','C.E','NIT','RUT','PASAPORTE') NOT NULL,
  `IDENTIFICACION` varchar(20) NOT NULL,
  `TELEFONO` varchar(15) NOT NULL,
  `DIRECCION` varchar(50) NOT NULL,
  `CORREO` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`ID_CLIENTE`, `NOMBRE`, `APELLIDO`, `TIPO_DOCUMENTO`, `IDENTIFICACION`, `TELEFONO`, `DIRECCION`, `CORREO`) VALUES
(2, 'CRISTIAN MIGUEL', 'gonzalez', 'C.C', '102334223432', '3143224516', 'dg61dsur#23a50', 'fantasmaempresa@gmail.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `ID_EMPLEADO` int(11) NOT NULL,
  `NOMBRE` varchar(50) DEFAULT NULL,
  `APELLIDO` varchar(50) DEFAULT NULL,
  `TIPO_DOCUMENTO` enum('C.C','C.E','NIT','RUT','PASAPORTE') DEFAULT NULL,
  `IDENTIFICACION` varchar(20) DEFAULT NULL,
  `TELEFONO` varchar(15) DEFAULT NULL,
  `DIRECCION` varchar(50) DEFAULT NULL,
  `CORREO` varchar(60) DEFAULT NULL,
  `CONTACTO_EMERGENCIA` varchar(50) DEFAULT NULL,
  `NOMBRE_CONTACTO_EMERGENCIA` varchar(50) DEFAULT NULL,
  `TIPO_CONTRATO` enum('INDEFINIDO','FIJO','OBRA LABOR') DEFAULT NULL,
  `FECHA_INGRESO` date DEFAULT NULL,
  `CARGO_ID` int(11) DEFAULT NULL,
  `EPS` enum('SALUD TOTAL','SANITAS','COMPENSAR','NUEVA EPS','FAMISANAR','ALIANSALUD') DEFAULT NULL,
  `PENSION` enum('COLPENSIONES','PROTECCION','PROVENIR') DEFAULT NULL,
  `CESANTIAS` enum('FNA','COLPENSIONES','PROTECCION','PORVENIR') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`ID_EMPLEADO`, `NOMBRE`, `APELLIDO`, `TIPO_DOCUMENTO`, `IDENTIFICACION`, `TELEFONO`, `DIRECCION`, `CORREO`, `CONTACTO_EMERGENCIA`, `NOMBRE_CONTACTO_EMERGENCIA`, `TIPO_CONTRATO`, `FECHA_INGRESO`, `CARGO_ID`, `EPS`, `PENSION`, `CESANTIAS`) VALUES
(8, 'dedd', 'ruiz', 'C.C', '79398030', '313122132222', 'NQS34 surv #20a40', 'sdjf@gmail.com', NULL, NULL, 'INDEFINIDO', '2023-07-12', NULL, NULL, 'COLPENSIONES', 'FNA'),
(9, 'dedd', 'ruiz', 'C.C', '79398030', '313122132222', 'NQS34 surv #20a40', 'sdjf@gmail.com', NULL, NULL, 'INDEFINIDO', '2023-07-12', NULL, NULL, 'COLPENSIONES', 'FNA'),
(10, 'omar', 'ruiz', 'C.C', '3456785', '3143224516', 'AVCALI-34#25', 'sdjf@gmail.com', NULL, NULL, 'INDEFINIDO', '2023-09-05', NULL, NULL, 'COLPENSIONES', 'FNA'),
(11, 'omar', 'ruiz', 'C.C', '3456785', '3143224516', 'AVCALI-34#25', 'sdjf@gmail.com', NULL, NULL, 'INDEFINIDO', '2023-09-05', NULL, NULL, 'COLPENSIONES', 'FNA'),
(12, 'cristian', 'gonzalez', 'C.C', '102334223432', '3143224516', 'dg61dsur#23a50', 'fantasmaempresa@gmail.com', NULL, NULL, 'INDEFINIDO', '2023-10-28', NULL, NULL, 'COLPENSIONES', 'FNA');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura_cabeza`
--

CREATE TABLE `factura_cabeza` (
  `ID_FACTURA` int(11) NOT NULL,
  `FECHA_EMISION` date DEFAULT NULL,
  `CLIENTE_COD` int(11) DEFAULT NULL,
  `EMPLEADO_COD` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `factura_cabeza`
--

INSERT INTO `factura_cabeza` (`ID_FACTURA`, `FECHA_EMISION`, `CLIENTE_COD`, `EMPLEADO_COD`) VALUES
(1, '2023-10-06', 2, 12);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura_detalle`
--

CREATE TABLE `factura_detalle` (
  `ID_FACTURADETALLE` int(11) NOT NULL,
  `FACTURA_COD` int(11) DEFAULT NULL,
  `FORMA_PAGO` enum('EFECTIVO','DATAFONO','CHEQUE','TRANSFERENCIAS') DEFAULT NULL,
  `PRODUCTO_COD` int(11) DEFAULT NULL,
  `CANTIDAD` double DEFAULT NULL,
  `PRECIO_UNITARIO` double DEFAULT NULL,
  `SUBTOTAL` double DEFAULT NULL,
  `IVA` double DEFAULT NULL,
  `DESCUENTO` double DEFAULT NULL,
  `NETO_PAGAR` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `factura_detalle`
--

INSERT INTO `factura_detalle` (`ID_FACTURADETALLE`, `FACTURA_COD`, `FORMA_PAGO`, `PRODUCTO_COD`, `CANTIDAD`, `PRECIO_UNITARIO`, `SUBTOTAL`, `IVA`, `DESCUENTO`, `NETO_PAGAR`) VALUES
(1, 1, 'EFECTIVO', 6, 1000, 500, 200, 19, 18, 5000000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nomina`
--

CREATE TABLE `nomina` (
  `ID_NOMINA` int(11) NOT NULL,
  `EMPLEADO_COD` int(11) DEFAULT NULL,
  `SALARIO` double DEFAULT NULL,
  `DIAS_TRABAJADOS` double DEFAULT NULL,
  `SALARIO_BASE` double DEFAULT NULL,
  `NO_HORAS_EXTRAS` double DEFAULT NULL,
  `TIPO_HORAS` enum('DIURNA','NOCTURNA','DOMINICAL','RECARGO NOCTURNA') DEFAULT NULL,
  `VALOR_HORAS` double DEFAULT NULL,
  `AUXILIO_TRANSPORTE` double DEFAULT NULL,
  `COMISIONES` double DEFAULT NULL,
  `TOTAL_DEVENGADO` double DEFAULT NULL,
  `PENSION` double DEFAULT NULL,
  `SALUD` double DEFAULT NULL,
  `PRESTAMOS_OTROS` double DEFAULT NULL,
  `TOTAL_DEDUCIDO` double DEFAULT NULL,
  `NETO_PAGAR` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `nomina`
--

INSERT INTO `nomina` (`ID_NOMINA`, `EMPLEADO_COD`, `SALARIO`, `DIAS_TRABAJADOS`, `SALARIO_BASE`, `NO_HORAS_EXTRAS`, `TIPO_HORAS`, `VALOR_HORAS`, `AUXILIO_TRANSPORTE`, `COMISIONES`, `TOTAL_DEVENGADO`, `PENSION`, `SALUD`, `PRESTAMOS_OTROS`, `TOTAL_DEDUCIDO`, `NETO_PAGAR`) VALUES
(1, 12, 100000000, 30, 10000000, 5000000, 'DIURNA', 500000, 118000, 50000, 0, 0, 0, 10000, 0, 0),
(2, 8, 100000000, 30, 20000000, 5000000, 'DIURNA', 500000, 118000, 70000, 0, 0, 0, 10000, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedido_cabeza`
--

CREATE TABLE `pedido_cabeza` (
  `ID_PEDIDO` int(11) NOT NULL,
  `FECHA_EXPEDICION` date DEFAULT NULL,
  `FECHA_ENTREGA` date DEFAULT NULL,
  `PROVEEDOR_COD` int(11) DEFAULT NULL,
  `EMPLEADO_COD` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pedido_cabeza`
--

INSERT INTO `pedido_cabeza` (`ID_PEDIDO`, `FECHA_EXPEDICION`, `FECHA_ENTREGA`, `PROVEEDOR_COD`, `EMPLEADO_COD`) VALUES
(1, '0000-00-00', '0000-00-00', 2, 12),
(2, '0000-00-00', '0000-00-00', 2, 12);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedido_detalle`
--

CREATE TABLE `pedido_detalle` (
  `ID_PEDIDODETALLE` int(11) NOT NULL,
  `PEDIDO_COD` int(11) DEFAULT NULL,
  `FORMA_PAGO` enum('EFECTIVO','DATAFONO','CHEQUE','TRANSFERENCIA') DEFAULT NULL,
  `PRODUCTO_COD` int(11) DEFAULT NULL,
  `CANTIDAD` int(11) DEFAULT NULL,
  `PRECIO_UNITARIO` double DEFAULT NULL,
  `SUBTOTAL` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pedido_detalle`
--

INSERT INTO `pedido_detalle` (`ID_PEDIDODETALLE`, `PEDIDO_COD`, `FORMA_PAGO`, `PRODUCTO_COD`, `CANTIDAD`, `PRECIO_UNITARIO`, `SUBTOTAL`) VALUES
(1, 1, 'EFECTIVO', NULL, 1000, 500000, 20000),
(2, 2, 'EFECTIVO', NULL, 1000, 600000, 30000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `ID_PRODUCTO` int(11) NOT NULL,
  `CATEGORIA` enum('ASEO','VESTUARIO','ALIMENTOS','ACCESORIOS') NOT NULL,
  `NOMBRE` varchar(100) NOT NULL,
  `CANTIDAD` int(255) NOT NULL,
  `LOTE` varchar(50) DEFAULT NULL,
  `FECHA_FABRICACION` date DEFAULT NULL,
  `FECHA_VENCIMIENTO` date DEFAULT NULL,
  `PRECIO_VENTA` double NOT NULL,
  `PRECIO_COMPRA` double NOT NULL,
  `PROVEEDOR_COD` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`ID_PRODUCTO`, `CATEGORIA`, `NOMBRE`, `CANTIDAD`, `LOTE`, `FECHA_FABRICACION`, `FECHA_VENCIMIENTO`, `PRECIO_VENTA`, `PRECIO_COMPRA`, `PROVEEDOR_COD`) VALUES
(6, 'ASEO', 'dedd', 100, '10', '2023-09-30', '2023-09-27', 10000000, 100000, 2),
(7, 'VESTUARIO', 'pañales klim', 1000, '10', '2023-09-28', '2023-09-01', 1000000, 500000, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `ID_PROVEEDORES` int(11) NOT NULL,
  `TIPO_DOCUMENTO` enum('C.C','C.E','NIT','RUT','PASAPORTE') NOT NULL,
  `NO_DOCUMENTO` varchar(50) NOT NULL,
  `RAZON_SOCIAL` varchar(100) NOT NULL,
  `DIRECCION` varchar(50) NOT NULL,
  `TELEFONO` varchar(50) NOT NULL,
  `CORREO` varchar(100) NOT NULL,
  `REPRESENTANTE` varchar(50) NOT NULL,
  `REPRESENTANTE_TELEFONO` varchar(50) NOT NULL,
  `REPRESENTANTE_CORREO_ELECTRONICO` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`ID_PROVEEDORES`, `TIPO_DOCUMENTO`, `NO_DOCUMENTO`, `RAZON_SOCIAL`, `DIRECCION`, `TELEFONO`, `CORREO`, `REPRESENTANTE`, `REPRESENTANTE_TELEFONO`, `REPRESENTANTE_CORREO_ELECTRONICO`) VALUES
(2, 'C.C', '79398030', 'la paz', 'NQS34 surv #20a40', '3414568797', 'sdjf@gmail.com', 'pedro', '3222222222222', 'rororfor@gmail.com');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cargos`
--
ALTER TABLE `cargos`
  ADD PRIMARY KEY (`ID_CARGO`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`ID_CLIENTE`);

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`ID_EMPLEADO`),
  ADD KEY `CARGO_ID` (`CARGO_ID`);

--
-- Indices de la tabla `factura_cabeza`
--
ALTER TABLE `factura_cabeza`
  ADD PRIMARY KEY (`ID_FACTURA`),
  ADD KEY `CLIENTE_COD` (`CLIENTE_COD`),
  ADD KEY `EMPLEADO_COD` (`EMPLEADO_COD`);

--
-- Indices de la tabla `factura_detalle`
--
ALTER TABLE `factura_detalle`
  ADD PRIMARY KEY (`ID_FACTURADETALLE`),
  ADD KEY `FACTURA_COD` (`FACTURA_COD`),
  ADD KEY `PRODUCTO_COD` (`PRODUCTO_COD`);

--
-- Indices de la tabla `nomina`
--
ALTER TABLE `nomina`
  ADD PRIMARY KEY (`ID_NOMINA`),
  ADD KEY `EMPLEADO_COD` (`EMPLEADO_COD`);

--
-- Indices de la tabla `pedido_cabeza`
--
ALTER TABLE `pedido_cabeza`
  ADD PRIMARY KEY (`ID_PEDIDO`),
  ADD KEY `PROVEEDOR_COD` (`PROVEEDOR_COD`),
  ADD KEY `EMPLEADO_COD` (`EMPLEADO_COD`);

--
-- Indices de la tabla `pedido_detalle`
--
ALTER TABLE `pedido_detalle`
  ADD PRIMARY KEY (`ID_PEDIDODETALLE`),
  ADD KEY `PEDIDO_COD` (`PEDIDO_COD`),
  ADD KEY `PRODUCTO_COD` (`PRODUCTO_COD`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`ID_PRODUCTO`),
  ADD KEY `PROVEEDOR_COD` (`PROVEEDOR_COD`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`ID_PROVEEDORES`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cargos`
--
ALTER TABLE `cargos`
  MODIFY `ID_CARGO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `ID_CLIENTE` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `empleados`
--
ALTER TABLE `empleados`
  MODIFY `ID_EMPLEADO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `factura_cabeza`
--
ALTER TABLE `factura_cabeza`
  MODIFY `ID_FACTURA` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `factura_detalle`
--
ALTER TABLE `factura_detalle`
  MODIFY `ID_FACTURADETALLE` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `nomina`
--
ALTER TABLE `nomina`
  MODIFY `ID_NOMINA` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `pedido_cabeza`
--
ALTER TABLE `pedido_cabeza`
  MODIFY `ID_PEDIDO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `pedido_detalle`
--
ALTER TABLE `pedido_detalle`
  MODIFY `ID_PEDIDODETALLE` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `ID_PRODUCTO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `ID_PROVEEDORES` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD CONSTRAINT `empleados_ibfk_1` FOREIGN KEY (`CARGO_ID`) REFERENCES `cargos` (`ID_CARGO`) ON DELETE CASCADE;

--
-- Filtros para la tabla `factura_cabeza`
--
ALTER TABLE `factura_cabeza`
  ADD CONSTRAINT `factura_cabeza_ibfk_1` FOREIGN KEY (`CLIENTE_COD`) REFERENCES `clientes` (`ID_CLIENTE`) ON DELETE CASCADE,
  ADD CONSTRAINT `factura_cabeza_ibfk_2` FOREIGN KEY (`EMPLEADO_COD`) REFERENCES `empleados` (`ID_EMPLEADO`) ON DELETE CASCADE;

--
-- Filtros para la tabla `factura_detalle`
--
ALTER TABLE `factura_detalle`
  ADD CONSTRAINT `factura_detalle_ibfk_1` FOREIGN KEY (`FACTURA_COD`) REFERENCES `factura_cabeza` (`ID_FACTURA`) ON DELETE CASCADE,
  ADD CONSTRAINT `factura_detalle_ibfk_2` FOREIGN KEY (`PRODUCTO_COD`) REFERENCES `productos` (`ID_PRODUCTO`) ON DELETE CASCADE;

--
-- Filtros para la tabla `nomina`
--
ALTER TABLE `nomina`
  ADD CONSTRAINT `nomina_ibfk_1` FOREIGN KEY (`EMPLEADO_COD`) REFERENCES `empleados` (`ID_EMPLEADO`) ON DELETE CASCADE;

--
-- Filtros para la tabla `pedido_cabeza`
--
ALTER TABLE `pedido_cabeza`
  ADD CONSTRAINT `pedido_cabeza_ibfk_1` FOREIGN KEY (`PROVEEDOR_COD`) REFERENCES `proveedores` (`ID_PROVEEDORES`) ON DELETE CASCADE,
  ADD CONSTRAINT `pedido_cabeza_ibfk_2` FOREIGN KEY (`EMPLEADO_COD`) REFERENCES `empleados` (`ID_EMPLEADO`) ON DELETE CASCADE;

--
-- Filtros para la tabla `pedido_detalle`
--
ALTER TABLE `pedido_detalle`
  ADD CONSTRAINT `pedido_detalle_ibfk_1` FOREIGN KEY (`PEDIDO_COD`) REFERENCES `pedido_cabeza` (`ID_PEDIDO`) ON DELETE CASCADE,
  ADD CONSTRAINT `pedido_detalle_ibfk_2` FOREIGN KEY (`PRODUCTO_COD`) REFERENCES `productos` (`ID_PRODUCTO`) ON DELETE CASCADE;

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`PROVEEDOR_COD`) REFERENCES `proveedores` (`ID_PROVEEDORES`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
