<?php
$conexion=mysqli_connect("localhost", "root", "", "pañalera");

$tipo=$_POST['opc'];
$valor=$_POST['car'];


if($tipo == "codigo")
{

    $registros=mysqli_query($conexion, "select id_producto,categoria,nombre,cantidad,lote,fecha_fabricacion,fecha_vencimiento,precio_venta,precio_compra,proveedor_cod from productos where id_producto=$valor") or die ("Problema en el Select".mysqli_error($conexion));

    if($reg=mysqli_fetch_array($registros))
    {

        $registros =mysqli_query($conexion, "select * from productos where id_producto=$valor") or die("Problemas en el Select".mysqli_error($conexion)); 
        echo "<br><br>Se efectuo la busqueda del Cargo Seleccionado <br><br>";

        $registros=mysqli_query($conexion, "select id_producto,categoria,nombre,cantidad,lote,fecha_fabricacion,fecha_vencimiento,precio_venta,precio_compra,proveedor_cod from productos where id_producto=$valor") or die ("Problema en el Select".mysqli_error($conexion));
        echo "<table table border='2' width='80%' style='border-collapse: collapse; margin: 20px auto;'><caption>REGISTROS ENTIDAD PROVEEDOR</caption><tr>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>COD PRODUCTO</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CATEGORIA</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>NOMBRE</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CANTIDAD</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>LOTE</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>FECHA FABRICACIÓN</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>FECHA VENCIMIENTO</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>PRECIO VENTA</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>PRECIO COMPRA</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CODIGO PROVEEDOR</th></tr><tr>";

        while($reg=mysqli_fetch_array($registros))
        {        
            echo "<td style='padding: 8px; text-align: center;'>".$reg['id_producto']."</td>"; 
            echo "<td style='padding: 8px; text-align: center;'>".$reg['categoria']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['nombre']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['cantidad']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['lote']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['fecha_fabricacion']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['fecha_vencimiento']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['precio_venta']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['precio_compra']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['proveedor_cod']."</td></tr>";
        }

    echo "</table>";
    }
    else
    {
        echo "<br><br>No existe el Proveedor Ingresado";
    }
}
else
{
    if($tipo == "nombre"){
        $registros=mysqli_query($conexion, "select id_producto,categoria,nombre,cantidad,lote,fecha_fabricacion,fecha_vencimiento,precio_venta,precio_compra,proveedor_cod from productos where nombre='$valor'") or die ("Problema en el Select".mysqli_error($conexion));
        if($reg=mysqli_fetch_array($registros))
        {
            $registros=mysqli_query($conexion, "select id_producto,categoria,nombre,cantidad,lote,fecha_fabricacion,fecha_vencimiento,precio_venta,precio_compra,proveedor_cod from productos where nombre='$valor'") or die ("Problema en el Select".mysqli_error($conexion));            
            echo "<br><br>Se efectuo la busqueda del Cargo Seleccionado <br><br>"; 

            $registros=mysqli_query($conexion, "select id_producto,categoria,nombre,cantidad,lote,fecha_fabricacion,fecha_vencimiento,precio_venta,precio_compra,proveedor_cod from productos where nombre='$valor'") or die ("Problema en el Select".mysqli_error($conexion));            
            echo "<table table border='2' width='80%' style='border-collapse: collapse; margin: 20px auto;'><caption>REGISTROS ENTIDAD PROVEEDOR</caption><tr>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>COD PRODUCTO</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CATEGORIA</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>NOMBRE</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CANTIDAD</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>LOTE</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>FECHA FABRICACIÓN</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>FECHA VENCIMIENTO</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>PRECIO VENTA</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>PRECIO COMPRA</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CODIGO PROVEEDOR</th></tr><tr>";

            while($reg=mysqli_fetch_array($registros))
            {        
                echo "<td style='padding: 8px; text-align: center;'>".$reg['id_producto']."</td>"; 
                echo "<td style='padding: 8px; text-align: center;'>".$reg['categoria']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['nombre']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['cantidad']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['lote']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['fecha_fabricacion']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['fecha_vencimiento']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['precio_venta']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['precio_compra']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['proveedor_cod']."</td></tr>";
            }
    
                echo "</table>";
        }
        else
        {
            echo "<br><br>No existe el Proveedor Ingresado";
        }
    }

}
mysqli_close($conexion)
?>

<div style="text-align: center; margin-top: 20px;">
<style>
    button{
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    padding: 10px 20px;
    cursor: pointer;
}
</style>
    <a href="buscarProducto.html"><button>Regresar </button></a>
    <a href="../index.html"><button>Pagina Principal</button></a>
</div>