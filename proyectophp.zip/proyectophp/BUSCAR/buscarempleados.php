<?php
$conexion = mysqli_connect("localhost", "root", "", "pañalera");

if (!$conexion) {
    die("Error en la conexión: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_empleado = $_POST['id_empleado'];

    $consulta = "SELECT * FROM empleados WHERE ID_EMPLEADO = $id_empleado";
    $resultado = mysqli_query($conexion, $consulta);

    if ($resultado) {
        if (mysqli_num_rows($resultado) > 0) {
            // Mostrar los resultados
            echo "<h2>Resultados de la búsqueda:</h2>";
            echo "<table border='1'>
                    <tr>
                        <th>ID Empleado</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Tipo de Documento</th>
                        <th>Identificación</th>
                        <th>Teléfono</th>
                        <th>Dirección</th>
                        <th>Correo</th>
                        <th>Tipo de Contrato</th>
                        <th>Fecha de Ingreso</th>
                        <th>Pensión</th>
                        <th>Cesantías</th>
                    </tr>";

            while ($fila = mysqli_fetch_assoc($resultado)) {
                echo "<tr>
                        <td>{$fila['ID_EMPLEADO']}</td>
                        <td>{$fila['NOMBRE']}</td>
                        <td>{$fila['APELLIDO']}</td>
                        <td>{$fila['TIPO_DOCUMENTO']}</td>
                        <td>{$fila['IDENTIFICACION']}</td>
                        <td>{$fila['TELEFONO']}</td>
                        <td>{$fila['DIRECCION']}</td>
                        <td>{$fila['CORREO']}</td>
                        <td>{$fila['TIPO_CONTRATO']}</td>
                        <td>{$fila['FECHA_INGRESO']}</td>
                        <td>{$fila['PENSION']}</td>
                        <td>{$fila['CESANTIAS']}</td>
                    </tr>";
            }

            echo "</table>";
        } else {
            echo "No se encontraron resultados para el ID de empleado proporcionado.";
        }
    } else {
        echo "Error en la consulta: " . mysqli_error($conexion);
    }

    mysqli_free_result($resultado);
}

mysqli_close($conexion);
?>
