<?php
$conexion=mysqli_connect("localhost", "root", "", "pañalera");

$tipo=$_POST['opc'];
$valor=$_POST['car'];


if($tipo == "cod")
{

    $registros=mysqli_query($conexion, "select id_cargo, descripcion, ubicacion, salario, comision from cargos where id_cargo=$valor") or die ("Problema en el Select".mysqli_error($conexion));

    if($reg=mysqli_fetch_array($registros))
    {

        $registros =mysqli_query($conexion, "select * from cargos where id_cargo=$valor") or die("Problemas en el Select".mysqli_error($conexion)); 
        echo "<br><br>Se efectuo la busqueda del Cargo Seleccionado <br><br>";

        $registros=mysqli_query($conexion, "select id_cargo, descripcion, ubicacion, salario, comision from cargos where id_cargo=$valor") or die ("Problema en el Select".mysqli_error($conexion));

        echo "<table table border='2' width='80%' style='border-collapse: collapse; margin: 20px auto;'><caption>REGISTROS ENTIDAD CARGOS </caption><tr>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CODIGO CARGO</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>NOMBRE CARGO </ th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>UBICACION </th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>SALARIO </th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>COMISION </th></tr><tr>";

        while($reg=mysqli_fetch_array($registros))
        {        
            echo "<td style='padding: 8px; text-align: center;'>".$reg['id_cargo']."</td>"; 
            echo "<td style='padding: 8px; text-align: center;'>".$reg['descripcion']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['ubicacion']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['salario']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['comision']."%</td></tr>";
        }

    echo "</table>";
    }
    else
    {
        echo "<br><br>No existe el Cargo Ingresado";
    }
}
else
{
    if($tipo == "nombre"){
        $registros=mysqli_query($conexion, "select id_cargo, descripcion, ubicacion, salario,comision from cargos where descripcion ='$valor'") or die ("Problema en el Select".mysqli_error($conexion));

        if($reg=mysqli_fetch_array($registros))
        {
            mysqli_query($conexion, "select * from cargos where descripcion ='$valor'") or die("Problemas en el Select".mysqli_error($conexion)); 
            echo "<br><br>Se efectuo la busqueda del Cargo Seleccionado <br><br>"; 
            $registros = mysqli_query($conexion, "select id_cargo, descripcion, ubicacion, salario, comision from cargos where descripcion ='$valor' ") or die ("Problema en el Select".mysqli_error($conexion));
    
            echo "<table border='2' width='80%' style='border-collapse: collapse; margin: 20px auto;'><caption>REGISTROS ENTIDAD CARGOS </caption><tr>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CODIGO CARGO</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>NOMBRE CARGO </th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>UBICACION </th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>SALARIO </th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>COMISION </th></tr><tr>"; 
            while ($reg=mysqli_fetch_array($registros))
            {
                echo "<td style='padding: 8px; text-align: center;'>".$reg['id_cargo']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['descripcion']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['ubicacion']."</td>"; 
                echo "<td style='padding: 8px; text-align: center;'>".$reg['salario']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['comision']."%</td></tr>";
            }
            echo "</table>";
        }
        else
        {
            echo "<br><br>No existe el Cargo Ingresado";
        }
    }

}
mysqli_close($conexion)
?>

<div style="text-align: center; margin-top: 20px;">
<style>
    button{
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    padding: 10px 20px;
    cursor: pointer;
}
</style>
    <a href="buscarCargo.html"><button>Regresar </button></a>
    <a href="../index.html"><button>Pagina Principal</button></a>
</div>