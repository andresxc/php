<?php
$conexion = mysqli_connect("localhost", "root", "", "pañalera");

if (!$conexion) {
    die("Error en la conexión: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_pedido = $_POST['id_pedido'];

    $consulta = "SELECT * FROM pedido_cabeza WHERE ID_PEDIDO = $id_pedido";
    $resultado = mysqli_query($conexion, $consulta);

    if ($resultado) {
        if (mysqli_num_rows($resultado) > 0) {
            // Mostrar los resultados
            echo "<h2>Resultados de la búsqueda:</h2>";
            echo "<table border='1'>
                    <tr>
                        <th>ID Pedido</th>
                        <th>ID Proveedor</th>
                        <th>ID Empleado</th>
                        <th>Fecha de Expedición</th>
                        <th>Fecha de Entrega</th>
                        <th>Forma de Pago</th>
                        <th>Cantidad</th>
                        <th>Precio Unitario</th>
                        <th>Subtotal</th>
                    </tr>";

            while ($fila = mysqli_fetch_assoc($resultado)) {
                echo "<tr>
                        <td>" . (isset($fila['ID_PEDIDO']) ? $fila['ID_PEDIDO'] : '') . "</td>
                        <td>" . (isset($fila['ID_PROVEEDOR']) ? $fila['ID_PROVEEDOR'] : '') . "</td>
                        <td>" . (isset($fila['ID_EMPLEADO']) ? $fila['ID_EMPLEADO'] : '') . "</td>
                        <td>" . (isset($fila['FECHA_EXPEDICION']) ? $fila['FECHA_EXPEDICION'] : '') . "</td>
                        <td>" . (isset($fila['FECHA_ENTREGA']) ? $fila['FECHA_ENTREGA'] : '') . "</td>
                        <td>" . (isset($fila['FORMA_PAGO']) ? $fila['FORMA_PAGO'] : '') . "</td>
                        <td>" . (isset($fila['CANTIDAD']) ? $fila['CANTIDAD'] : '') . "</td>
                        <td>" . (isset($fila['PRECIO_UNITARIO']) ? $fila['PRECIO_UNITARIO'] : '') . "</td>
                        <td>" . (isset($fila['SUBTOTAL']) ? $fila['SUBTOTAL'] : '') . "</td>
                      </tr>";
            }

            echo "</table>";
        } else {
            echo "No se encontraron resultados para el ID de pedido proporcionado.";
        }
    } else {
        echo "Error en la consulta: " . mysqli_error($conexion);
    }

    mysqli_free_result($resultado);
}

mysqli_close($conexion);
?>
