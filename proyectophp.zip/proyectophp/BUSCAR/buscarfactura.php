<?php
$conexion = mysqli_connect("localhost", "root", "", "pañalera");

if (!$conexion) {
    die("Error en la conexión: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_factura = $_POST['id_factura'];

    $consulta = "SELECT * FROM factura_cabeza WHERE ID_FACTURA = $id_factura";
    $resultado = mysqli_query($conexion, $consulta);

    if ($resultado) {
        if (mysqli_num_rows($resultado) > 0) {
            // Mostrar los resultados
            echo "<h2>Resultados de la búsqueda:</h2>";
            echo "<table border='1'>
                    <tr>
                        <th>ID Factura</th>
                        <th>Fecha de Emisión</th>
                        <th>Código Cliente</th>
                        <th>Código Empleado</th>
                    </tr>";

            while ($fila = mysqli_fetch_assoc($resultado)) {
                echo "<tr>
                        <td>{$fila['ID_FACTURA']}</td>
                        <td>{$fila['FECHA_EMISION']}</td>
                        <td>{$fila['CLIENTE_COD']}</td>
                        <td>{$fila['EMPLEADO_COD']}</td>
                    </tr>";
            }

            echo "</table>";
        } else {
            echo "No se encontraron resultados para el ID de factura proporcionado.";
        }
    } else {
        echo "Error en la consulta: " . mysqli_error($conexion);
    }

    mysqli_free_result($resultado);
}

mysqli_close($conexion);
?>

