<?php
$conexion=mysqli_connect("localhost", "root", "", "pañalera");

$tipo=$_POST['opc'];
$valor=$_POST['car'];


if($tipo == "codigo")
{

    $registros=mysqli_query($conexion, "select id_proveedores,tipo_documento,no_documento,razon_social,direccion,telefono,correo,representante,representante_telefono,representante_correo_electronico from proveedores where id_proveedores=$valor") or die ("Problema en el Select".mysqli_error($conexion));

    if($reg=mysqli_fetch_array($registros))
    {

        $registros =mysqli_query($conexion, "select * from proveedores where id_proveedores=$valor") or die("Problemas en el Select".mysqli_error($conexion)); 
        echo "<br><br>Se efectuo la busqueda del Cargo Seleccionado <br><br>";

        $registros=mysqli_query($conexion, "select id_proveedores,tipo_documento,no_documento,razon_social,direccion,telefono,correo,representante,representante_telefono,representante_correo_electronico from proveedores where id_proveedores=$valor") or die ("Problema en el Select".mysqli_error($conexion));

        echo "<table table border='2' width='80%' style='border-collapse: collapse; margin: 20px auto;'><caption>REGISTROS ENTIDAD PROVEEDOR</caption><tr>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CODIGO PROVEEDOR</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>TIPO DOCUMENTO</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>NUMERO DOCUMENTO</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>RAZON SOCIAL </th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>DIRECCIÓN</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>TELEFONO</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CORREO</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>REPRESENTANTE</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>TELEFONO REPRESENTANTE</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CORREO REPRESENTANTE_</th></tr><tr>";

        while($reg=mysqli_fetch_array($registros))
        {        
            echo "<td style='padding: 8px; text-align: center;'>".$reg['id_proveedores']."</td>"; 
            echo "<td style='padding: 8px; text-align: center;'>".$reg['tipo_documento']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['no_documento']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['razon_social']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['direccion']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['telefono']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['correo']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['representante']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['representante_telefono']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['representante_correo_electronico']."</td></tr>";
        }

    echo "</table>";
    }
    else
    {
        echo "<br><br>No existe el Proveedor Ingresado";
    }
}
else
{
    if($tipo == "razon"){
        $registros=mysqli_query($conexion, "select id_proveedores,tipo_documento,no_documento,razon_social,direccion,telefono,correo,representante,representante_telefono,representante_correo_electronico from proveedores where razon_social='$valor'") or die ("Problema en el Select".mysqli_error($conexion));

        if($reg=mysqli_fetch_array($registros))
        {
            $registros =mysqli_query($conexion, "select * from proveedores where razon_social='$valor'") or die("Problemas en el Select".mysqli_error($conexion)); 
            echo "<br><br>Se efectuo la busqueda del Cargo Seleccionado <br><br>"; 

            $registros=mysqli_query($conexion, "select id_proveedores,tipo_documento,no_documento,razon_social,direccion,telefono,correo,representante,representante_telefono,representante_correo_electronico from proveedores where razon_social='$valor'") or die ("Problema en el Select".mysqli_error($conexion));    
            echo "<table table border='2' width='80%' style='border-collapse: collapse; margin: 20px auto;'><caption>REGISTROS ENTIDAD PROVEEDOR</caption><tr>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CODIGO PROVEEDOR</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>TIPO DOCUMENTO</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>NUMERO DOCUMENTO</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>RAZON SOCIAL </th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>DIRECCIÓN</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>TELEFONO</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CORREO</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>REPRESENTANTE</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>TELEFONO REPRESENTANTE</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CORREO REPRESENTANTE_</th></tr><tr>";

            while($reg=mysqli_fetch_array($registros))
            {        
                echo "<td style='padding: 8px; text-align: center;'>".$reg['id_proveedores']."</td>"; 
                echo "<td style='padding: 8px; text-align: center;'>".$reg['tipo_documento']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['no_documento']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['razon_social']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['direccion']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['telefono']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['correo']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['representante']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['representante_telefono']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['representante_correo_electronico']."</td></tr>";
            }
    
                echo "</table>";
        }
        else
        {
            echo "<br><br>No existe el Proveedor Ingresado";
        }
    }

}
mysqli_close($conexion)
?>

<div style="text-align: center; margin-top: 20px;">
<style>
    button{
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    padding: 10px 20px;
    cursor: pointer;
}
</style>
    <a href="buscarProveedor.html"><button>Regresar </button></a>
    <a href="../index.html"><button>Pagina Principal</button></a>
</div>