<?php
$conexion=mysqli_connect("localhost", "root", "", "pañalera");

$tipo=$_POST['opc'];
$valor=$_POST['car'];


if($tipo == "codigo")
{

    $registros=mysqli_query($conexion, "select id_cliente, nombre, apellido, tipo_documento, identificacion, telefono, direccion, correo from clientes where id_cliente=$valor") or die ("Problema en el Select".mysqli_error($conexion));

    if($reg=mysqli_fetch_array($registros))
    {

        $registros =mysqli_query($conexion, "select * from clientes where id_cliente=$valor") or die("Problemas en el Select".mysqli_error($conexion)); 
        echo "<br><br>Se efectuo la busqueda del Cargo Seleccionado <br><br>";

        $registros=mysqli_query($conexion, "select id_cliente, nombre, apellido, tipo_documento, identificacion, telefono, direccion, correo from clientes where id_cliente=$valor") or die ("Problema en el Select".mysqli_error($conexion));

        echo "<table table border='2' width='80%' style='border-collapse: collapse; margin: 20px auto;'><caption>REGISTROS ENTIDAD CLIENTES</caption><tr>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CODIGO CLIENTE</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>NOMBRE</ th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>APELLIDO </th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>TIPO DOCUMENTO</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>IDENTIFICACIÓN</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>TELEFONO</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>DIRECCIÓN</th>
        <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CORREO</th></tr><tr>";

        while($reg=mysqli_fetch_array($registros))
        {        
            echo "<td style='padding: 8px; text-align: center;'>".$reg['id_cliente']."</td>"; 
            echo "<td style='padding: 8px; text-align: center;'>".$reg['nombre']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['apellido']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['tipo_documento']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['identificacion']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['telefono']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['direccion']."</td>";
            echo "<td style='padding: 8px; text-align: center;'>".$reg['correo']."</td></tr>";
        }

    echo "</table>";
    }
    else
    {
        echo "<br><br>No existe el Cliente Ingresado";
    }
}
else
{
    if($tipo == "apellido"){
        $registros=mysqli_query($conexion, "select id_cliente, nombre, apellido, tipo_documento, identificacion, telefono, direccion, correo from clientes where apellido ='$valor'") or die ("Problema en el Select".mysqli_error($conexion));

        if($reg=mysqli_fetch_array($registros))
        {
            mysqli_query($conexion, "select * from clientes where nombre ='$valor'") or die("Problemas en el Select".mysqli_error($conexion)); 
            echo "<br><br>Se efectuo la busqueda del Cargo Seleccionado <br><br>"; 
            $registros = mysqli_query($conexion, "select id_cliente, nombre, apellido, tipo_documento, identificacion, telefono, direccion, correo from clientes where apellido ='$valor' ") or die ("Problema en el Select".mysqli_error($conexion));
    
            echo "<table table border='2' width='80%' style='border-collapse: collapse; margin: 20px auto;'><caption>REGISTROS ENTIDAD CLIENTES</caption><tr>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CODIGO CLIENTE</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>NOMBRE</ th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>APELLIDO </th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>TIPO DOCUMENTO</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>IDENTIFICACIÓN</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>TELEFONO</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>DIRECCIÓN</th>
            <th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CORREO</th></tr><tr>";

            while($reg=mysqli_fetch_array($registros))
            {        
                echo "<td style='padding: 8px; text-align: center;'>".$reg['id_cliente']."</td>"; 
                echo "<td style='padding: 8px; text-align: center;'>".$reg['nombre']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['apellido']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['tipo_documento']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['identificacion']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['telefono']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['direccion']."</td>";
                echo "<td style='padding: 8px; text-align: center;'>".$reg['correo']."</td></tr>";
            }
                echo "</table>";
        }
        else
        {
            echo "<br><br>No existe el Cliente Ingresado";
        }
    }

}
mysqli_close($conexion)
?>

<div style="text-align: center; margin-top: 20px;">
<style>
    button{
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    padding: 10px 20px;
    cursor: pointer;
}
</style>
    <a href="buscarCliente.html"><button>Regresar </button></a>
    <a href="../index.html"><button>Pagina Principal</button></a>
</div>