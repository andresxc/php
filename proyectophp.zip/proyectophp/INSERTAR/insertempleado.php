<?php
$conexion = mysqli_connect("localhost", "root", "", "pañalera");
if (!$conexion) {
    die("Error en la conexión: " . mysqli_connect_error());
}

$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$tipo_documento = $_POST['tipo_documento'];
$identificacion = $_POST['identificacion'];
$telefono = $_POST['telefono'];
$direccion = $_POST['direccion'];
$correo = $_POST['correo'];
$tipo_contrato = $_POST['tipo_contrato'];
$fecha_ingreso = $_POST['fecha_ingreso'];
$pension = $_POST['pension'];
$cesantias = $_POST['cesantias'];

$sql = "INSERT INTO empleados (nombre, apellido, tipo_documento, identificacion, telefono, direccion, correo, tipo_contrato, fecha_ingreso, pension, cesantias) 
        VALUES ('$nombre', '$apellido', '$tipo_documento', '$identificacion', '$telefono', '$direccion', '$correo', '$tipo_contrato', '$fecha_ingreso', '$pension', '$cesantias')";

if (mysqli_query($conexion, $sql)) {
    echo "Registro Ingresado Correctamente <br><br>";
} else {
    echo "Error en el Insert: " . mysqli_error($conexion);
}

mysqli_close($conexion);
?>
