<?php
$conexion = mysqli_connect("localhost", "root", "", "pañalera");
if (!$conexion) {
    die("Error en la conexión: " . mysqli_connect_error());
}

// Obtener el ID_EMPLEADO del formulario (ajusta esto según el campo real del formulario)
$empleado_cod = $_POST['empleado_cod'];

// Obtener datos del formulario (ajusta esto según los campos reales del formulario)
$salario = $_POST['salario'];
$dias_trabajados = $_POST['dias_trabajados'];
$salario_base = $_POST['salario_base'];
$horas_extras = $_POST['horas_extras'];
$tipo_horas = $_POST['tipo_horas'];
$valor_horas = $_POST['valor_horas'];
$auxilio_transporte = $_POST['auxilio_transporte'];
$comisiones = $_POST['comisiones'];
$total_devengado = isset($_POST['total_devengado']) ? $_POST['total_devengado'] : 0;
$pension = isset($_POST['pension']) ? $_POST['pension'] : 0;
$salud = isset($_POST['salud']) ? $_POST['salud'] : 0;
$prestamos_otros = $_POST['prestamos_otros'];
$total_deducido = isset($_POST['total_deducido']) ? $_POST['total_deducido'] : 0;
$neto_pagar = isset($_POST['neto_pagar']) ? $_POST['neto_pagar'] : 0;

// Verificar si el empleado existe
$result = mysqli_query($conexion, "SELECT ID_EMPLEADO FROM empleados WHERE ID_EMPLEADO = '$empleado_cod'");
if ($row = mysqli_fetch_assoc($result)) {
    $id_empleado = $row['ID_EMPLEADO'];

    // Consulta SQL para nomina
    $sql_nomina = "INSERT INTO nomina (EMPLEADO_COD, SALARIO, DIAS_TRABAJADOS, SALARIO_BASE, NO_HORAS_EXTRAS, TIPO_HORAS, VALOR_HORAS, AUXILIO_TRANSPORTE, COMISIONES, TOTAL_DEVENGADO, PENSION, SALUD, PRESTAMOS_OTROS, TOTAL_DEDUCIDO, NETO_PAGAR) 
                   VALUES ('$id_empleado', '$salario', '$dias_trabajados', '$salario_base', '$horas_extras', '$tipo_horas', '$valor_horas', '$auxilio_transporte', '$comisiones', '$total_devengado', '$pension', '$salud', '$prestamos_otros', '$total_deducido', '$neto_pagar')";

    // Ejecutar la consulta para nomina
    if (mysqli_query($conexion, $sql_nomina)) {
        echo "Registro de Nómina Ingresado Correctamente <br><br>";
    } else {
        echo "Error en el Insert de Nómina: " . mysqli_error($conexion);
    }
} else {
    echo "No se encontró el empleado con ID: $empleado_cod";
}

// Cerrar la conexión
mysqli_close($conexion);
?>



