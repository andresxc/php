<?php
$conexion = mysqli_connect("localhost","root","","pañalera");

$categoria = $_POST['categoria'];
$nombre = $_POST['nombre'];
$cantidad = $_POST['cantidad'];
$lote = $_POST['lote'];
$fFabricacion = $_POST['fecha_fabricacion'];
$fVenta = $_POST['fecha_venta'];
$pVenta = $_POST['precio_venta'];
$pCompra = $_POST['precio_compra'];
$provcod = $_POST['id_proveedor'];

mysqli_query($conexion,"insert into productos(categoria,nombre,cantidad,lote,fecha_fabricacion,fecha_vencimiento,precio_venta,precio_compra,proveedor_cod) values ('$categoria','$nombre',$cantidad,'$lote','$fFabricacion','$fVenta',$pVenta,$pCompra,$provcod)") or die ("Problema en el Insert".mysqli_error($conexion));
echo "<br><br> Registro Ingresado Correctamente <br><br>";

$registros = mysqli_query($conexion, "select id_producto,categoria,nombre,cantidad,lote,fecha_fabricacion,fecha_vencimiento,precio_venta,precio_compra,proveedor_cod from productos") or die("Problema en el Select".mysqli_error($conexion));

echo "<table border='2' width='90%' style='border-collapse: collapse; margin: 20px auto;'>";
echo "<caption style='font-size: 1.2em; text-align: center; font-family: arial;'><b> REGISTROS ENTIDAD PRODUCTOS</b>  </caption>";
echo "<tr>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> CODIGO PRODUCTO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> CATEGORIA </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> NOMBRE </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> CANTIDAD </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> LOTE </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> FECHA DE FABRICACIÓN </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> FECHA DE VENCIMIENTO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> PRECIO DE VENTA </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> PRECIO DE COMPRA </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> CODIGO PROVEEDOR </th>";
echo "</tr>";

while($reg = mysqli_fetch_array($registros))
{
    echo "<td style='padding: 8px; text-align: center;'>".$reg['id_producto']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['categoria']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['nombre']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['cantidad']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['lote']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['fecha_fabricacion']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['fecha_vencimiento']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['precio_venta']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['precio_compra']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['proveedor_cod']."</td>";
    echo "</tr>";
}
echo "</table>";
mysqli_close($conexion)
?>
<div style="text-align: center; margin-top: 20px;">
<style>
    button{
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    padding: 10px 20px;
    cursor: pointer;
}
</style>
    <a href="../FORMS/productos.php"><button>Regresar</button></a>
    <a href="../index.html"><button>Pagina Principal</button></a>
</div>