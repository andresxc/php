<?php
$conexion = mysqli_connect("localhost","root","","pañalera");
$tipo_documento = $_POST['tipo_documento'];
$identificacion = $_POST['identificacion'];
$razonSocial = $_POST['razonSocial'];
$direccion = $_POST['direccion'];
$telefono = $_POST['telefono'];
$correo = $_POST['correo'];
$representante = $_POST['representante'];
$telefonoRep = $_POST['representanteTelefono'];
$correoRep = $_POST['representanteCorreo'];

mysqli_query($conexion,"insert into proveedores(tipo_documento,no_documento,razon_social,direccion,telefono,correo,representante,representante_telefono,representante_correo_electronico) values ('$tipo_documento','$identificacion','$razonSocial','$direccion','$telefono','$correo','$representante','$telefonoRep','$correoRep')") or die ("Problema en el Insert".mysqli_error($conexion));
echo "<br><br> Registro Ingresado Correctamente <br><br>";

$registros = mysqli_query($conexion, "select id_proveedores,razon_social,tipo_documento,no_documento,direccion,telefono,correo,representante,representante_telefono,representante_correo_electronico from proveedores") or die("Problema en el Select".mysqli_error($conexion));

echo "<table border='2' width='90%' style='border-collapse: collapse; margin: 20px auto;'>";
echo "<caption style='font-size: 1.2em; text-align: center; font-family: arial;'><b> REGISTROS ENTIDAD PROVEEDORES</b>  </caption>";
echo "<tr>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> CODIGO PROVEEDOR </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> RAZON SOCIAL </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> TIPO DOCUMENTO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> IDENTIFICACIÓN </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> DIRECCIÓN </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> TELEFONO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> CORREO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> REPRESENTANTE </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> TELEFONO REPRESENTANTE </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> CORREO REPRESENTANTE </th>";
echo "</tr>";

while($reg = mysqli_fetch_array($registros))
{
    echo "<td style='padding: 8px; text-align: center;'>".$reg['id_proveedores']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['razon_social']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['tipo_documento']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['no_documento']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['direccion']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['telefono']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['correo']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['representante']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['representante_telefono']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['representante_correo_electronico']."</td>";
    echo "</tr>";
}
echo "</table>";
mysqli_close($conexion)
?>

<div style="text-align: center; margin-top: 20px;">
<style>
    button{
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    padding: 10px 20px;
    cursor: pointer;
}
</style>
    <a href="../FORMS/proveedores.html"><button>Regresar</button></a>
    <a href="../index.html"><button>Pagina Principal</button></a>
</div>