<?php
$conexion = mysqli_connect("localhost", "root", "", "pañalera");
if (!$conexion) {
    die("Error en la conexión: " . mysqli_connect_error());
}

// Obtener datos del formulario (puedes ajustar esto según los campos reales del formulario)
$id_factura = $_POST['id_factura'];
$cliente_cod = $_POST['cliente_cod'];
$empledado_cod = $_POST['empledado_cod'];
$producto_cod = $_POST['producto_cod'];
$forma_pago = $_POST['forma_pago'];
$fecha_emision = $_POST['fecha_emision'];
$cantidad = $_POST['cantidad'];
$precio_unitario = $_POST['precio_unitario'];
$subtotal = $_POST['subtotal'];
$iva = $_POST['iva'];
$descuento = $_POST['descuento'];
$neto_pagar = $_POST['neto_pagar'];

// Consulta SQL con JOIN
$sql = "INSERT INTO factura_cabeza (ID_FACTURA, FECHA_EMISION, CLIENTE_COD, EMPLEADO_COD) 
        VALUES ('$id_factura', '$fecha_emision', '$cliente_cod', '$empledado_cod')";

// Ejecutar la consulta para factura_cabeza
if (mysqli_query($conexion, $sql)) {
    echo "Registro de Factura Cabeza Ingresado Correctamente <br><br>";
} else {
    echo "Error en el Insert de Factura Cabeza: " . mysqli_error($conexion);
}

// Consulta SQL para factura_detalle
$sql_detalle = "INSERT INTO factura_detalle (FACTURA_COD, FORMA_PAGO, PRODUCTO_COD, CANTIDAD, PRECIO_UNITARIO, SUBTOTAL, IVA, DESCUENTO, NETO_PAGAR) 
                VALUES ('$id_factura', '$forma_pago', '$producto_cod', '$cantidad', '$precio_unitario', '$subtotal', '$iva', '$descuento', '$neto_pagar')";

// Ejecutar la consulta para factura_detalle
if (mysqli_query($conexion, $sql_detalle)) {
    echo "Registro de Detalle de Factura Ingresado Correctamente <br><br>";
} else {
    echo "Error en el Insert de Detalle de Factura: " . mysqli_error($conexion);
}

// Cerrar la conexión
mysqli_close($conexion);
?>
