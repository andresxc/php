<?php
$conexion = mysqli_connect("localhost", "root", "", "pañalera");
if (!$conexion) {
    die("Error en la conexión: " . mysqli_connect_error());
}

$id_pedido = $_POST['id_pedido'];
$proveedor_cod = $_POST['proveedor_cod'];
$empleado_cod = $_POST['empleado_cod'];
$fecha_expedicion = $_POST['fecha_expedicion'];
$fecha_entrega = $_POST['fecha_entrega'];
$forma_pago = $_POST['forma_pago'];
$cantidad = $_POST['cantidad'];
$precio_unitario = $_POST['precio_unitario'];
$subtotal = $_POST['subtotal'];

$sql_cabeza = "INSERT INTO pedido_cabeza (ID_PEDIDO, PROVEEDOR_COD, EMPLEADO_COD, FECHA_EXPEDICION, FECHA_ENTREGA, FORMA_PAGO, CANTIDAD, PRECIO_UNITARIO, SUBTOTAL) 
        VALUES ('$id_pedido', '$proveedor_cod', '$empleado_cod', '$fecha_expedicion', '$fecha_entrega', '$forma_pago', '$cantidad', '$precio_unitario', '$subtotal')";

if (mysqli_query($conexion, $sql_cabeza)) {
    echo "Registro de Pedido Cabeza Ingresado Correctamente <br><br>";
} else {
    echo "Error en el Insert de Pedido Cabeza: " . mysqli_error($conexion);
}

$sql_detalle = "INSERT INTO pedido_detalle (ID_PEDIDO, PROVEEDOR_COD, EMPLEADO_COD, FECHA_EXPEDICION, FECHA_ENTREGA, FORMA_PAGO, CANTIDAD, PRECIO_UNITARIO, SUBTOTAL) 
            VALUES ('$id_pedido', '$proveedor_cod', '$empleado_cod', '$fecha_expedicion', '$fecha_entrega', '$forma_pago', '$cantidad', '$precio_unitario', '$subtotal')";

if (mysqli_query($conexion, $sql_detalle)) {
    echo "Registro de Detalle de Pedido Ingresado Correctamente <br><br>";
} else {
    echo "Error en el Insert de Detalle de Pedido: " . mysqli_error($conexion);
}

mysqli_close($conexion);
?>
