<?php
$conexion = mysqli_connect("localhost", "root", "", "pañalera");
$registros = mysqli_query($conexion, "SELECT * FROM pedido_cabeza") or die("Problema en el Select" . mysqli_error($conexion));

echo "<table border='2' width='80%' style='border-collapse: collapse; margin: 20px auto;'>";
echo "<caption style='font-size: 1.2em; text-align: center; font-family: arial;'><b>REGISTROS ENTIDAD PEDIDO</b></caption>";
echo "<tr>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>ID Pedido</th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>ID Proveedor</th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>ID Empleado</th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>Fecha de Expedición</th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>Fecha de Entrega</th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>Forma de Pago</th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>Cantidad</th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>Precio Unitario</th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>Subtotal</th>";
echo "</tr>";

while ($reg = mysqli_fetch_array($registros)) {
    echo "<tr>";
    echo "<td style='padding: 8px; text-align: center;'>" . (isset($reg['ID_PEDIDO']) ? $reg['ID_PEDIDO'] : '') . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . (isset($reg['ID_PROVEEDOR']) ? $reg['ID_PROVEEDOR'] : '') . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . (isset($reg['ID_EMPLEADO']) ? $reg['ID_EMPLEADO'] : '') . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . (isset($reg['FECHA_EXPEDICION']) ? $reg['FECHA_EXPEDICION'] : '') . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . (isset($reg['FECHA_ENTREGA']) ? $reg['FECHA_ENTREGA'] : '') . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . (isset($reg['FORMA_PAGO']) ? $reg['FORMA_PAGO'] : '') . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . (isset($reg['CANTIDAD']) ? $reg['CANTIDAD'] : '') . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . (isset($reg['PRECIO_UNITARIO']) ? $reg['PRECIO_UNITARIO'] : '') . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . (isset($reg['SUBTOTAL']) ? $reg['SUBTOTAL'] : '') . "</td>";
    echo "</tr>";
}

echo "</table>";
mysqli_close($conexion);
?>
