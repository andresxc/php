<?php
$conexion = mysqli_connect("localhost", "root", "", "pañalera");
$registros = mysqli_query($conexion, "SELECT ID_PEDIDO, FECHA_EXPEDICION, FECHA_ENTREGA, PROVEEDOR_COD, EMPLEADO_COD FROM pedido_cabeza") or die("Problema en el Select" . mysqli_error($conexion));

echo "<table border='2' width='80%' style='border-collapse: collapse; margin: 20px auto;'>";
echo "<caption style='font-size: 1.2em; text-align: center; font-family: arial;'><b>REGISTROS ENTIDAD PEDIDO_CABEZA</b></caption>";
echo "<tr>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>ID PEDIDO</th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>FECHA EXPEDICION</th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>FECHA ENTREGA</th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>PROVEEDOR COD</th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>EMPLEADO COD</th>";
echo "</tr>";

while ($reg = mysqli_fetch_array($registros)) {
    echo "<tr>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['ID_PEDIDO'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['FECHA_EXPEDICION'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['FECHA_ENTREGA'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['PROVEEDOR_COD'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['EMPLEADO_COD'] . "</td>";
    echo "</tr>";
}

echo "</table>";
mysqli_close($conexion)
?>
