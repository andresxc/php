<?php
$conexion = mysqli_connect("localhost","root","","pañalera");
$registros = mysqli_query($conexion, "select id_empleado,nombre,apellido,tipo_documento,identificacion,telefono,direccion,correo,nombre_contacto_emergencia,contacto_emergencia,tipo_contrato,fecha_ingreso,cargo_id,eps,pension,cesantias  from empleados") or die("Problema en el Select".mysqli_error($conexion));

echo "<table border='2' width='80%' style='border-collapse: collapse; margin: 20px auto;'>";
echo "<caption style='font-size: 1.2em; text-align: center; font-family: arial;'><b> REGISTROS ENTIDAD EMPLEADOS</b>  </caption>";
echo "<tr>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> CODIGO EMPLEADO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> NOMBRES </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> APPELIDOS </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> TIPO DOCUMENTO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> IDENTIFICACIÓN </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> TELEFONO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> DIRECCIÓN </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> CORREO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> CONTACTO EMERGENCIA </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> TELEFONO CONTACTO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> TIPO CONTRATO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> FECHA INGRESO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> CODIGO CARGO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> EPS </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> PENSION </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> CESANTIAS </th>";
echo "</tr>";

while($reg = mysqli_fetch_array($registros))
{
    echo "<td style='padding: 8px; text-align: center;'>".$reg['id_empleado']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['nombre']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['apellido']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['tipo_documento']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['identificacion']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['telefono']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['direccion']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['correo']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['nombre_contacto_emergencia']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['contacto_emergencia']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['tipo_contrato']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['fecha_ingreso']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['cargo_id']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['eps']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['pension']."</td>";
    echo "<td style='padding: 8px; text-align: center;'>".$reg['cesantias']."</td>";
    echo "</tr>";
}
echo "</table>";
mysqli_close($conexion)

?>

<div style="text-align: center; margin-top: 20px;">
<style>
    button{
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    padding: 10px 20px;
    cursor: pointer;
}
</style>
    <a href="../index.html"><button>Pagina Principal</button></a>
</div>