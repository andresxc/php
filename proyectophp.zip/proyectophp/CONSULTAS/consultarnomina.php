<?php
$conexion = mysqli_connect("localhost", "root", "", "pañalera");
$registros = mysqli_query($conexion, "SELECT ID_NOMINA, EMPLEADO_COD, SALARIO, DIAS_TRABAJADOS, SALARIO_BASE, NO_HORAS_EXTRAS, TIPO_HORAS, VALOR_HORAS, AUXILIO_TRANSPORTE, COMISIONES, TOTAL_DEVENGADO, PENSION, SALUD, PRESTAMOS_OTROS, TOTAL_DEDUCIDO, NETO_PAGAR FROM nomina") or die("Problema en el Select" . mysqli_error($conexion));

echo "<table border='2' width='90%' style='border-collapse: collapse; margin: 20px auto;'>";
echo "<caption style='font-size: 1.2em; text-align: center; font-family: arial;'><b> REGISTROS ENTIDAD NOMINA</b>  </caption>";
echo "<tr>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> ID NOMINA </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> EMPLEADO COD </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> SALARIO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> DIAS TRABAJADOS </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> SALARIO BASE </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> NO HORAS EXTRAS </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> TIPO HORAS </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> VALOR HORAS </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> AUXILIO TRANSPORTE </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> COMISIONES </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> TOTAL DEVENGADO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> PENSION </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> SALUD </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> PRESTAMOS OTROS </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> TOTAL DEDUCIDO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> NETO PAGAR </th>";
echo "</tr>";

while ($reg = mysqli_fetch_array($registros)) {
    echo "<tr>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['ID_NOMINA'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['EMPLEADO_COD'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['SALARIO'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['DIAS_TRABAJADOS'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['SALARIO_BASE'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['NO_HORAS_EXTRAS'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['TIPO_HORAS'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['VALOR_HORAS'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['AUXILIO_TRANSPORTE'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['COMISIONES'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['TOTAL_DEVENGADO'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['PENSION'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['SALUD'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['PRESTAMOS_OTROS'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['TOTAL_DEDUCIDO'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['NETO_PAGAR'] . "</td>";
    echo "</tr>";
}

echo "</table>";
mysqli_close($conexion);
?>
