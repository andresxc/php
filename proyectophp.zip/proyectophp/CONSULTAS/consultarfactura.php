<?php
$conexion = mysqli_connect("localhost", "root", "", "pañalera");

// Consulta para factura_cabeza
$registros_factura_cabeza = mysqli_query($conexion, "SELECT ID_FACTURA, FECHA_EMISION, CLIENTE_COD, EMPLEADO_COD FROM factura_cabeza") or die("Problema en el Select de factura_cabeza" . mysqli_error($conexion));

// Consulta para factura_detalle
$registros_factura_detalle = mysqli_query($conexion, "SELECT ID_FACTURADETALLE, FACTURA_COD, FORMA_PAGO, PRODUCTO_COD, CANTIDAD, PRECIO_UNITARIO, SUBTOTAL, IVA, DESCUENTO, NETO_PAGAR FROM factura_detalle") or die("Problema en el Select de factura_detalle" . mysqli_error($conexion));

echo "<h2>Factura Cabecera</h2>";
echo "<table border='2' width='90%' style='border-collapse: collapse; margin: 20px auto;'>";
echo "<caption style='font-size: 1.2em; text-align: center; font-family: arial;'><b> REGISTROS ENTIDAD FACTURA CABECERA</b>  </caption>";
echo "<tr>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> ID FACTURA </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> FECHA EMISION </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> CLIENTE COD </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> EMPLEADO COD </th>";
echo "</tr>";

while ($reg_factura_cabeza = mysqli_fetch_array($registros_factura_cabeza)) {
    echo "<tr>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg_factura_cabeza['ID_FACTURA'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg_factura_cabeza['FECHA_EMISION'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg_factura_cabeza['CLIENTE_COD'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg_factura_cabeza['EMPLEADO_COD'] . "</td>";
    echo "</tr>";
}

echo "</table>";

echo "<h2>Factura Detalle</h2>";
echo "<table border='2' width='90%' style='border-collapse: collapse; margin: 20px auto;'>";
echo "<caption style='font-size: 1.2em; text-align: center; font-family: arial;'><b> REGISTROS ENTIDAD FACTURA DETALLE</b>  </caption>";
echo "<tr>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> ID FACTURA DETALLE </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> FACTURA COD </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> FORMA PAGO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> PRODUCTO COD </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> CANTIDAD </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> PRECIO UNITARIO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> SUBTOTAL </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> IVA </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> DESCUENTO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'> NETO PAGAR </th>";
echo "</tr>";

while ($reg_factura_detalle = mysqli_fetch_array($registros_factura_detalle)) {
    echo "<tr>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg_factura_detalle['ID_FACTURADETALLE'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg_factura_detalle['FACTURA_COD'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg_factura_detalle['FORMA_PAGO'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg_factura_detalle['PRODUCTO_COD'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg_factura_detalle['CANTIDAD'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg_factura_detalle['PRECIO_UNITARIO'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg_factura_detalle['SUBTOTAL'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg_factura_detalle['IVA'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg_factura_detalle['DESCUENTO'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg_factura_detalle['NETO_PAGAR'] . "</td>";
    echo "</tr>";
}

echo "</table>";

mysqli_close($conexion);
?>
