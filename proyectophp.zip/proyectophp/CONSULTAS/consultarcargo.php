<?php
$conexion = mysqli_connect("localhost","root","","pañalera");
$registros = mysqli_query($conexion, "select id_cargo,descripcion,ubicacion,salario, comision from cargos") or die("Problema en el Select".mysqli_error($conexion));

echo "<table border='2' width='80%' style='border-collapse: collapse; margin: 20px auto;'>";
echo "<caption style='font-size: 1.2em; text-align: center; font-family: arial;'><b>REGISTROS ENTIDAD CARGOS</b></caption>";
echo "<tr>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>CODIGO CARGO </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>NOMBRE </th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>UBICACIÓN</th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>SALARIO</th>";
echo "<th style='background-color: #f2f2f2; padding: 8px; text-align: center;'>COMISION</th>";
echo "</tr>";

while ($reg = mysqli_fetch_array($registros)) {
    echo "<tr>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['id_cargo'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['descripcion'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['ubicacion'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['salario'] . "</td>";
    echo "<td style='padding: 8px; text-align: center;'>" . $reg['comision'] . "%</td>";
    echo "</tr>";
}

echo "</table>";
mysqli_close($conexion)

?>

<div style="text-align: center; margin-top: 20px;">
<style>
    button{
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    padding: 10px 20px;
    cursor: pointer;
}
</style>
    <a href="../index.html"><button>Pagina Principal</button></a>
</div>